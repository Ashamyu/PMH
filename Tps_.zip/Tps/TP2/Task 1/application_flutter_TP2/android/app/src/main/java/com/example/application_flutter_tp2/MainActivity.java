package com.example.application_flutter_tp2;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
