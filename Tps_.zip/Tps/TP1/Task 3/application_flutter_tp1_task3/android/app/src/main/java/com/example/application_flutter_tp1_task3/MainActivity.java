package com.example.application_flutter_tp1_task3;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
